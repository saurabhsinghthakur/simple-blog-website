
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <div class="row">
        	<div class="col-sm-6">
        		<h1 class="mt-4">Blogs</h1>		
        	</div>
        	<div class="col-sm-6 text-right">
        		<br><a href="<?php echo e(route('blogs.add')); ?>" class="btn btn-primary">Add New</a>
        	</div>
        </div>
    	<?php if($message = Session::get('success')): ?>
	  		<div class="alert alert-success">
	  			<p style="margin: 0"><?php echo e($message); ?></p>
	  		</div>
	  	<?php endif; ?>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Blogs
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
								<th>Id</th>
								<th>Image</th>
								<th>Title</th>
								<th>Description</th>
								<th style="min-width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
							<?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(++$i); ?></td>
								<td><img src="<?php echo e(url('public/'.$blog->image)); ?>" style="max-height: 50px;"></td>
								<td><?php echo e($blog->title); ?></td>
								<td><?php echo e($blog->description); ?></td>
								<td>
                                    <a href="<?php echo e(route('blogs.edit', encrypt($blog->id))); ?>" class="btn btn-xs btn-primary btn-sm">Edit</a>&nbsp;
									<a href="<?php echo e(route('blogs.destroy', $blog->id)); ?>" class="btn btn-xs btn-danger btn-sm">Delete</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/blogs/index.blade.php ENDPATH**/ ?>