
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Add Blogs</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Add Blogs
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <form method="post" enctype="multipart/form-data" action="<?php echo e(route('blogs.create')); ?>"><?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label class="small mb-1" for="title">Title</label>
                            <input class="form-control py-12" id="title" type="text" placeholder="Enter title" name="title"  required=""/>
                            <?php if($errors->has('title')): ?>
                                <span class="text-danger"><?php echo e($errors->first('title')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="small mb-1" for="title">Image</label><br>
                            <input class="py-12" id="image" type="file" name="image"/>
                            <?php if($errors->has('image')): ?>
                                <span class="text-danger"><?php echo e($errors->first('image')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <label class="small mb-1" for="title">Description</label>
                            <textarea class="form-control py-12" id="description" type="text" placeholder="Enter description" name="description"  required=""/></textarea>
                            <?php if($errors->has('description')): ?>
                                <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                            <?php endif; ?>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/blogs/create.blade.php ENDPATH**/ ?>