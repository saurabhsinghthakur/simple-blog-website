
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Add Player</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Add Player
            </div>
            <div class="card-body">
                <div class="table-responsive">
                	<form method="post" enctype="multipart/form-data" action="<?php echo e(route('players.create')); ?>"><?php echo csrf_field(); ?>
	                    <div class="form-group">
	                        <label class="small mb-1" for="title">First Name</label>
	                        <input class="form-control py-12" id="first_name" type="text" placeholder="Enter first name" name="first_name"  required=""/>
							<?php if($errors->has('first_name')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Last Name</label>
	                        <input class="form-control py-12" id="last_name" type="text" placeholder="Enter first name" name="last_name" required=""/>
							<?php if($errors->has('last_name')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Image</label><br>
	                        <input class="py-12" id="image" type="file" name="image"/>
							<?php if($errors->has('image')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('image')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Player Jersey Number</label>
	                        <input class="form-control py-12" id="player_jersey_number" type="text" placeholder="Enter player jersey number" name="player_jersey_number" required=""/>
							<?php if($errors->has('player_jersey_number')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('player_jersey_number')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Country</label>
	                        <input class="form-control py-12" id="country" type="text" placeholder="Enter country" name="country" required=""/>
							<?php if($errors->has('country')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('country')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <button class="btn btn-primary">Save</button>
	                    </div>
		            </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/players/create.blade.php ENDPATH**/ ?>