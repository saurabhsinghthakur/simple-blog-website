
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <div class="row">
        	<div class="col-sm-6">
        		<h1 class="mt-4">Players</h1>		
        	</div>
        	<div class="col-sm-6 text-right">
        		<br><a href="<?php echo e(route('players.add')); ?>" class="btn btn-primary">Add New</a>
        	</div>
        </div>
    	<?php if($message = Session::get('success')): ?>
	  		<div class="alert alert-success">
	  			<p style="margin: 0"><?php echo e($message); ?></p>
	  		</div>
	  	<?php endif; ?>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Players
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
								<th>Id</th>
								<th>First Name</th>
								<th>Last Name</th>
								<th>Image</th>
                                <th>Player Jersey Name</th>
                                <th>Country</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
							<?php $__currentLoopData = $players; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(++$i); ?></td>
								<td><?php echo e($single->first_name); ?></td>
								<td><?php echo e($single->last_name); ?></td>
                                <td><?php echo e($single->image_uri); ?></td>
                                <td><?php echo e($single->player_jersey_number); ?></td>
                                <td><?php echo e($single->country); ?></td>
								<td>
									<a href="<?php echo e(route('players.destroy', $single->id)); ?>" class="btn btn-xs btn-danger">Delete</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/players/index.blade.php ENDPATH**/ ?>