
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Add Match</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Add Match
            </div>
            <div class="card-body">
                <div class="table-responsive">
                	<form method="post" enctype="multipart/form-data" action="<?php echo e(route('matches.create')); ?>"><?php echo csrf_field(); ?>
                		<div class="form-row" style="margin: 0">
		                    <div class="form-group col-sm-3">
		                        <label class="small mb-1" for="team1">Team 1</label>
		                        <select class="form-control" name="team1">
		                        	<option value="">Select Team 1</option>
		                        	<?php if($teams): ?>
		                        		<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<option value="<?php echo e($single->id); ?>"><?php echo e($single->name); ?></option>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        	<?php endif; ?>
		                        </select>
								<?php if($errors->has('name')): ?>
				                	<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
				                <?php endif; ?>
		                    </div>

		                    <div class="form-group col-sm-3">
		                        <label class="small mb-1" for="team2">Team 2</label><br>
		                        <select class="form-control" name="team2">
		                        	<option value="">Select Team 2</option>
		                        	<?php if($teams): ?>
		                        		<?php $__currentLoopData = $teams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $single): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		                        			<option value="<?php echo e($single->id); ?>"><?php echo e($single->name); ?></option>
		                        		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		                        	<?php endif; ?>
		                        </select>
								<?php if($errors->has('team2')): ?>
				                	<span class="text-danger"><?php echo e($errors->first('team2')); ?></span>
				                <?php endif; ?>
		                    </div>

		                    <div class="form-group col-sm-3">
		                        <label class="small mb-1" for="title">Winner</label>
		                        <input class="form-control py-12" id="winner" type="text" placeholder="Enter winner" name="winner" required=""/>
								<?php if($errors->has('winner')): ?>
				                	<span class="text-danger"><?php echo e($errors->first('winner')); ?></span>
				                <?php endif; ?>
		                    </div>

		                    <div class="form-group col-sm-3"><br>
		                        <button class="btn btn-primary">Save</button>
		                    </div>
		                </div>
		            </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/matches/create.blade.php ENDPATH**/ ?>