
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Add Teams</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Add Teams
            </div>
            <div class="card-body">
                <div class="table-responsive">
                	<form method="post" enctype="multipart/form-data" action="<?php echo e(route('points.create')); ?>"><?php echo csrf_field(); ?>
	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Name</label>
	                        <input class="form-control py-12" id="name" type="text" placeholder="Enter name" name="name"  required=""/>
							<?php if($errors->has('name')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Logo</label><br>
	                        <input class="py-12" id="logo" type="file" name="logo"/>
							<?php if($errors->has('logo')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('logo')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <label class="small mb-1" for="title">Club State</label>
	                        <input class="form-control py-12" id="club_state" type="text" placeholder="Enter club state" name="club_state"  required=""/>
							<?php if($errors->has('club_state')): ?>
			                	<span class="text-danger"><?php echo e($errors->first('club_state')); ?></span>
			                <?php endif; ?>
	                    </div>

	                    <div class="form-group">
	                        <button class="btn btn-primary">Save</button>
	                    </div>
		            </form>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/teams/create.blade.php ENDPATH**/ ?>