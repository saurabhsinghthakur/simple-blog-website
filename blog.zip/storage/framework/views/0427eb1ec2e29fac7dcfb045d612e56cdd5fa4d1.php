
<?php $__env->startSection('content'); ?>
<main>
    <div class="container-fluid">
        <div class="row">
        	<div class="col-sm-6">
        		<h1 class="mt-4">Points</h1>		
        	</div>
        	<div class="col-sm-6 text-right">
        		<br><a href="<?php echo e(route('points.add')); ?>" class="btn btn-primary">Add New</a>
        	</div>
        </div>
    	<?php if($message = Session::get('success')): ?>
	  		<div class="alert alert-success">
	  			<p style="margin: 0"><?php echo e($message); ?></p>
	  		</div>
	  	<?php endif; ?>

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Teams
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
								<th>Id</th>
								<th>Name</th>
								<th>Point</th>
								<th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
							<?php $__currentLoopData = $points; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(++$i); ?></td>
								<td><?php echo e($point->name); ?></td>
								<td><?php echo e($point->point); ?></td>
								<td>
									<a href="<?php echo e(route('points.show', $point->id)); ?>" class="btn btn-xs btn-info">Show</a>
									<a href="<?php echo e(route('points.destroy', $point->id)); ?>" class="btn btn-xs btn-danger">Delete</a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\TestMatches\TestMatch\resources\views/points/index.blade.php ENDPATH**/ ?>