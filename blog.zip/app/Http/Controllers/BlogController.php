<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Blog;
use Redirect;
use Validator;
use Illuminate\Support\Facades\Input;

class BlogController extends Controller
{
	public function index()
	{
	    $blogs = Blog::get();
	    return view('blogs.index', compact('blogs'))->with('i');
	}

	public function add()
	{
	    return view('blogs.create');
	}

	public function create(Request $request)
	{
		$validator = Validator::make(
            $request->all(), [
                'title'       => 'required',
                'description' => 'required',
                'image'        => 'required|mimes:jpeg,png,jpg'
            ]
        );
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator)->withInput();
        }
        $blogs = new Blog();
        $blogs->title = $request->title;
        $blogs->description = $request->description;

        $image = "";
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $path = public_path('/assets/uploads');
            $name = rand(10,10000).time().'.'.$image->getClientOriginalExtension();
            $image->move($path, $name);
            $image = '/assets/uploads'.'/'.$name;
        }
        $blogs->image = $image;
        if($blogs->save()) {
            return redirect()->route('blogs.index')->with('success',__('Successfully saved!'));
        } else {
            return back()->with('success',__('Successfully deleted!'));
        }
	}

	public function edit($id)
	{
		$id = decrypt($id);
		$blog = Blog::find($id);
	    return view('blogs.edit', compact('blog'));
	}


	public function update(Request $request)
	{
		$validator = Validator::make(
            $request->all(), [
                'title'       => 'required',
                'description' => 'required'
            ]
        );
        if ($validator->fails()) {
            return Redirect::back()->withErrors($validator)->withInput();
        }
        $blogs = Blog::find(decrypt($request->id));
        $blogs->title = $request->title;
        $blogs->description = $request->description;

        $image = $request->old_image;
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $path = public_path('/assets/uploads');
            $name = rand(10,10000).time().'.'.$image->getClientOriginalExtension();
            $image->move($path, $name);
            $image = '/assets/uploads'.'/'.$name;
        }
        $blogs->image = $image;
        if($blogs->save()) {
            return redirect()->route('blogs.index')->with('success',__('Successfully saved!'));
        } else {
            return back()->with('success',__('Successfully saved!'));
        }
	}	

	public function delete(Request $request)
	{
	    if(Blog::destroy($request->id))
	    {
	        return back()->with('success',__('Successfully deleted!'));
	    } else {
	        return back()->with('error',__('Sorry! Something went wrong!'));
	    }
	}
}