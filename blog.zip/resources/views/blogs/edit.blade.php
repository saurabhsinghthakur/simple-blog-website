@extends('layouts.master')
@section('content')
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Edit Blogs</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Edit Blogs
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <form method="post" enctype="multipart/form-data" action="{{ route('blogs.update', encrypt($blog->id)) }}">
                        @csrf
                        <div class="form-group">
                            <label class="small mb-1" for="title">Title</label>
                            <input class="form-control py-12" id="title" type="text" placeholder="Enter title" name="title" required="" value="{{$blog->title}}" />
                            @if($errors->has('title'))
                                <span class="text-danger">{{ $errors->first('title') }}</span>
                            @endif
                        </div>
                        <div class="form-group col-sm-6">
                            <label class="small mb-1" for="title">Image</label><br>
                            <input class="py-12" id="image" type="file" name="image"/>
                            <input type="hidden" name="old_image" value="{{$blog->image}}" />
                            @if($errors->has('image'))
                                <span class="text-danger">{{ $errors->first('image') }}</span>
                            @endif
                        </div>

                        <div class="form-group col-sm-6">
                            <label class="small mb-1" for="title">Preview</label><br>
                            <img src="{{url('public/'.$blog->image)}}" style="max-height: 80px" />
                        </div>

                        <div class="form-group">
                            <label class="small mb-1" for="title">Description</label>
                            <textarea class="form-control py-12" id="description" type="text" placeholder="Enter description" name="description"  required=""/>{{ $blog->description }}</textarea>
                            @if($errors->has('description'))
                                <span class="text-danger">{{ $errors->first('description') }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection