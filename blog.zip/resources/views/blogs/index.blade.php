@extends('layouts.master')
@section('content')
<main>
    <div class="container-fluid">
        <div class="row">
        	<div class="col-sm-6">
        		<h1 class="mt-4">Blogs</h1>		
        	</div>
        	<div class="col-sm-6 text-right">
        		<br><a href="{{ route('blogs.add') }}" class="btn btn-primary">Add New</a>
        	</div>
        </div>
    	@if($message = Session::get('success'))
	  		<div class="alert alert-success">
	  			<p style="margin: 0">{{ $message }}</p>
	  		</div>
	  	@endif

        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Blogs
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
								<th>Id</th>
								<th>Image</th>
								<th>Title</th>
								<th>Description</th>
								<th style="min-width: 120px;">Actions</th>
                            </tr>
                        </thead>
                        <tbody>
							@foreach($blogs as $blog)
							<tr>
								<td>{{ ++$i }}</td>
								<td><img src="{{url('public/'.$blog->image)}}" style="max-height: 50px;"></td>
								<td>{{$blog->title}}</td>
								<td>{{$blog->description}}</td>
								<td>
                                    <a href="{{ route('blogs.edit', encrypt($blog->id)) }}" class="btn btn-xs btn-primary btn-sm">Edit</a>&nbsp;
									<a href="{{ route('blogs.destroy', $blog->id) }}" class="btn btn-xs btn-danger btn-sm">Delete</a>
								</td>
							</tr>
							@endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection