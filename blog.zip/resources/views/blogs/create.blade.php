@extends('layouts.master')
@section('content')
<main>
    <div class="container-fluid">
        <h1 class="mt-4">Add Blogs</h1>
        <div class="card mb-4">
            <div class="card-header">
                <i class="fas fa-table mr-1"></i>
                Add Blogs
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <form method="post" enctype="multipart/form-data" action="{{ route('blogs.create') }}">@csrf
                        <div class="form-group">
                            <label class="small mb-1" for="title">Title</label>
                            <input class="form-control py-12" id="title" type="text" placeholder="Enter title" name="title"  required=""/>
                            @if($errors->has('title'))
                                <span class="text-danger">{{ $errors->first('title') }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label class="small mb-1" for="title">Image</label><br>
                            <input class="py-12" id="image" type="file" name="image"/>
                            @if($errors->has('image'))
                                <span class="text-danger">{{ $errors->first('image') }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <label class="small mb-1" for="title">Description</label>
                            <textarea class="form-control py-12" id="description" type="text" placeholder="Enter description" name="description"  required=""/></textarea>
                            @if($errors->has('description'))
                                <span class="text-danger">{{ $errors->first('description') }}</span>
                            @endif
                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</main>
@endsection